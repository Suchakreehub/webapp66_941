<?php
require 'conn.php';
$sql_update="INSERT INTO dvd(dvdid,dvdname,dvdstudio,dvdgenre,dvdprice) VALUES ('$_POST[dvdid]','$_POST[dvdname]','$_POST[dvdstudio]' ,'$_POST[dvdgenre]' ,'$_POST[dvdprice]')";

$result= $conn->query($sql_update);

if(!$result) {
    die("Error God Damn it : ". $conn->error);
} else {

echo "Insert Success <br>";
header("refresh: 1; url=http://localhost/dvdshop/dvdmain.php");
}

?>