<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
</head>

</nav>
<body class="container">
    
    <form id="form1" name="form1" method="post" action="insertmemsucess.php">
        <P>
            <label for="memid">ID</label>
            <input type="text" name="memid" id="memid"/>
            

        </p>

        <p>

            <label for="memname">ชื่อ</label>
            <input type="text" name="memname" id="memname">

        </p>

        <p>

            <label for="memlastname">นามสกุล</label>

            <input type="text" name="memlastname" id="memlastname">

        </p>

        <p>

            <label for="memaddress">ที่อยู่</label>

            <input type="text" name="memaddress" id="memaddress">

        </p>

        <p>

            <label for="memtele">เบอร์โทร</label>

            <input type="text" name="memtele" id="memtele">

        </p>
        <input type="submit" class="btn btn-success" value="บันทึก">
        <a class="btn btn-success" href='membermain.php'>Home</a>
    </form>
</body>

</html> 