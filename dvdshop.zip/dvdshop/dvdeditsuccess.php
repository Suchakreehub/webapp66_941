<?php
require 'conn.php';
$sql_update="UPDATE dvd SET dvdname='$_POST[dvdname]',dvdstudio='$_POST[dvdstudio]' ,dvdgenre='$_POST[dvdgenre]' ,dvdprice='$_POST[dvdprice]' WHERE dvdid='$_POST[dvdid]' ";

$result= $conn->query($sql_update);

if(!$result) {
    die("Error God Damn it : ". $conn->error);
} else {

echo "Edit Success <br>";
header("refresh: 1; url=http://localhost/dvdshop/dvdmain.php");
}

?>