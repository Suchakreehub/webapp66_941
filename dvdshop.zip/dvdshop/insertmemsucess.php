<?php
require 'conn.php';
$sql_update="INSERT INTO customer(memid,memname,memlastname,memaddress,memtele) VALUES ('$_POST[memid]','$_POST[memname]','$_POST[memlastname]' ,'$_POST[memaddress]' ,'$_POST[memtele]')";

$result= $conn->query($sql_update);

if(!$result) {
    die("Error God Damn it : ". $conn->error);
} else {

echo "Insert Success <br>";
header("refresh: 1; url=http://localhost/dvdshop/membermain.php");
}

?>