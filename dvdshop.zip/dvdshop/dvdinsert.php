<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Movie</title>
</head>
<h1>เพิ่มหนัง</h1>
<body class="container">
    <form id="form1" name="form1" method="post" action="dvdinsuccess.php">
        <P>
            <label for="dvdid">ID</label>
            <input type="text" name="dvdid" id="dvdid"/>
            

        </p>

        <p>

            <label for="dvdname">ชื่อหนัง</label>
            <input type="text" name="dvdname" id="dvdname">

        </p>

        <p>

            <label for="dvdstudio">จากค่าย</label>

            <input type="text" name="dvdstudio" id="dvdstudio">

        </p>

        <p>

            <label for="dvdgenre">แนวหนัง</label>

            <input type="text" name="dvdgenre" id="dvdgenre">

        </p>

        <p>

            <label for="dvdprice">ราคา</label>

            <input type="text" name="dvdprice" id="dvdprice">

        </p>
        <input type="submit" class="btn btn-success" value="บันทึก">
        <a class="btn btn-success" href='dvdmain.php'>Home</a>
    </form>
</body>

</html> 