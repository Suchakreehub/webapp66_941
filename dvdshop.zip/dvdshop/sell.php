<?php
    require 'conn.php';
    $sql = "SELECT * FROM sellhistory";
    $result = $conn->query($sql);
    if(!$result){
        die("Error : ". $conn->$conn_error);
    }
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-v1XZhfsfFtlhSFl5n5hW5I3wzFaa5w1xw21ww/iW5lxRRm0E5znZLb5g5aIfR5PDI" crossorigin="anonymous"></script>

    <title>การขาย</title>
</head>

<body>
<nav class="navbar navbar-expand-sm bg-light">

<div class="container-fluid">
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="dvdmain.php">ภาพยนต์</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="membermain.php">สมาชิก</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="sell.php">การขาย</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="actor.php">นักแสดง</a>
    </li>
  </ul>
</div>

</nav>
    <div class="container">
        <h1>บันทึกการขาย</h1><br>
        <form id="form1" name="form1" method="post" action="savesellhistory.php">
        
        <P>
            <label for="sellid">Sell ID</label>
            <input type="text" name="sellid" id="sellid"/>
            

        </p>
    
        <P>
            <label for="sellid">ชื่อ</label>
            <select name="customer" id="customer">
            <?php
                require 'conn.php';

                // Query to retrieve members from the 'member' table
                $memberQuery = "SELECT memid, memname, memlastname FROM customer";
                $memberResult = $conn->query($memberQuery);

                // Loop through the results and create options for the dropdown
                while ($memberRow = $memberResult->fetch_assoc()) {
                    echo "<option value='" . $memberRow['memid'] . "'>" . $memberRow['memname'] . " " . $memberRow['memlastname'] . "</option>";
                }

                // Close the member query result
                $memberResult->close();
            ?>
        </select><br>
        </p>
        <P>
            <label for="sellid">หนัง</label>
            <select name="dvd" id="dvd">
            <?php
                // Query to retrieve DVDs from the 'dvd' table
                $dvdQuery = "SELECT dvdid, dvdname FROM dvd";
                $dvdResult = $conn->query($dvdQuery);

                // Loop through the results and create options for the dropdown
                while ($dvdRow = $dvdResult->fetch_assoc()) {
                    echo "<option value='" . $dvdRow['dvdid'] . "'>" . $dvdRow['dvdname'] . "</option>";
                }

                // Close the DVD query result
                $dvdResult->close();

            ?>
        </select><br>
            

        </p>

        <input type="submit" class="btn btn-success" value="บันทึก">
        <a class="btn btn-success" href='membermain.php'>Home</a>
    </form>

    <br><br>
    <div class="container">
        <h1>ประวัติการขาย</h1><br>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col-4">เรื่อง</th>
                    <th scope="col-4">ผู้ซื้อ</th>

                </tr>
            </thead>
            <tbody>
                <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            $sellid = $row["sellid"];
                            $dvdid = $row["dvdid"];
                            $memid = $row["memid"];
                    
                            // Query to retrieve customer name based on memid
                            $customerQuery = "SELECT memname, memlastname FROM customer WHERE memid = '$memid'";
                            $customerResult = $conn->query($customerQuery);
                            $customerRow = $customerResult->fetch_assoc();
                            $customerName = $customerRow["memname"] . " " . $customerRow["memlastname"];
                    
                            // Query to retrieve DVD name based on dvdid
                            $dvdQuery = "SELECT dvdname FROM dvd WHERE dvdid = '$dvdid'";
                            $dvdResult = $conn->query($dvdQuery);
                            $dvdRow = $dvdResult->fetch_assoc();
                            $dvdName = $dvdRow["dvdname"];
                            echo "<tr><td>$sellid</td><td>$dvdName</td><td>$customerName</td>";
                            echo "</tr>";    
                        }
                    }else {
                        echo "0 results";
                    }
                ?>
            </tbody>
        </table>
    </div>

</body>
</html>