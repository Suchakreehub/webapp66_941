<?php
require 'conn.php';
$sql_update="UPDATE customer SET memname='$_POST[memname]',memlastname='$_POST[memlastname]' ,memaddress='$_POST[memaddress]' ,memtele='$_POST[memtele]' WHERE memid='$_POST[memid]' ";

$result= $conn->query($sql_update);

if(!$result) {
    die("Error God Damn it : ". $conn->error);
} else {

echo "Edit Success <br>";
header("refresh: 1; url=http://localhost/dvdshop/membermain.php");
}

?>