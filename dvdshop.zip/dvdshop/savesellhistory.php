<?php
    require 'conn.php';

    // รับค่า member และ dvd จากแบบฟอร์ม
    $memberId = $_POST['customer'];
    $dvdId = $_POST['dvd'];

    // Query สำหรับการ Insert ข้อมูลในตาราง sellhistory
    $insertQuery = "INSERT INTO sellhistory (sellid,memid, dvdid) VALUES ('$_POST[sellid]','$memberId', '$dvdId')";

    // ทำการ Insert ข้อมูล
    if ($conn->query($insertQuery) === TRUE) {
        echo "เพิ่มข้อมูลสำเร็จ";
    } else {
        echo "เกิดข้อผิดพลาดในการเพิ่มข้อมูล: " . $conn->error;
    }

    // ปิดการเชื่อมต่อฐานข้อมูล
    $conn->close();
    header("refresh: 1; url=http://localhost/dvdshop/sell.php");
?>
