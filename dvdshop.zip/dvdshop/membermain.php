<?php
    require 'conn.php';
    $sql = "SELECT * FROM customer";
    $result = $conn->query($sql);
    if(!$result){
        die("Error : ". $conn->$conn_error);
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-v1XZhfsfFtlhSFl5n5hW5I3wzFaa5w1xw21ww/iW5lxRRm0E5znZLb5g5aIfR5PDI" crossorigin="anonymous"></script>

    <title>Member</title>
</head>

<body>
<nav class="navbar navbar-expand-sm bg-light">

<div class="container-fluid">
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="dvdmain.php">ภาพยนต์</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="membermain.php">สมาชิก</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="sell.php">การขาย</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="actor.php">นักแสดง</a>
    </li>
  </ul>
</div>

</nav>

    <div class="container">
        <h1>Member</h1><br>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col-4">ชื่อ-นามสกุล</th>
                    <th scope="col-4">ที่อยู่</th>
                    <th scope="col-4">เบอร์โทร</th>
                    <th scope="col-4">Edit</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr><td>".$row["memid"]."</td>"."<td>".$row["memname"]." ".$row["memlastname"]."</td>"."<td>".$row["memaddress"]."</td>"."<td>".$row["memtele"]."</td>"."<td>"."<a class='btn btn-warning' href='memedit.php?memid=".$row["memid"]."'>Edit</a>"."</td>";
                            echo "</tr>";    
                        }
                    }else {
                        echo "0 results";
                    }
                    $conn->close();
                ?>
            </tbody>
        </table>
        
        <a class="btn btn-success" href='insertmember.php'>Insert member</a>
    </div>
    
</body>
</html>