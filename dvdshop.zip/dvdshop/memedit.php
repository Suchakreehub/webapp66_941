<?php
if(!isset($_GET['memid'])){
    header("refresh: 1; url=http://localhost/dvdshop/membermain.php");
}
require 'conn.php';
$sql = "SELECT * FROM customer WHERE memid='$_GET[memid]'";
$result = $conn->query($sql);
$row = mysqli_fetch_array($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
</head>

<body class="container">
<nav class="navbar navbar-expand-sm bg-light">

<div class="container-fluid">
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="dvdmain.php">ภาพยนต์</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="membermain.php">สมาชิก</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="sell.php">การขาย</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="actor.php">นักแสดง</a>
    </li>
  </ul>
</div>

</nav>
    <form id="form1" name="form1" method="post" action="memeditsuccess.php">
        
        <P>
            <label for="memid">ID</label>
            <?php
                echo $_GET["memid"];
            ?>

        </p>

        <p>

            <label for="sname">ชื่อ</label>
            <input type="text" name="memid" id="memid" value="<?=$row['memid'];?>" hidden>
            <input type="text" name="memname" id="memname" value="<?=$row['memname'];?>" />

        </p>

        <p>

            <label for="memlastname">นามสกุล</label>

            <input type="text" name="memlastname" id="memlastname" value="<?=$row['memlastname'];?>" />

        </p>

        <p>

            <label for="memaddress">ที่อยู่</label>

            <input type="text" name="memaddress" id="memaddress" value="<?=$row['memaddress'];?>" />

        </p>

        <p>

            <label for="telephone">เบอร์โทร</label>

            <input type="text" name="memtele" id="memtele" value="<?=$row['memtele'];?>" />

        </p>
        <input type="submit" class="btn btn-success" value="บันทึก">
        <a class="btn btn-success" href='membermain.php'>Home</a>
    </form>
</body>

</html>